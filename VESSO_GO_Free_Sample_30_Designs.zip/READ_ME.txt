VESSO GO - FREE SAMPLE (30 designs)
6 designs from each of our 1000-design mega bundles: wheels, gears, garage ornaments, keychain tags, brake rotors.
SVG (red hairline = cut) + DXF (mm). Personal use. Please do not re-share the files - share the page link instead:
https://vesso-go.github.io/
Full bundles (1000 designs each, SVG + DXF + STL): https://www.etsy.com/shop/VESSOGO
